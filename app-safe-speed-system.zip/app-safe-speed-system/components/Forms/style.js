import style from 'styled-components/native'

const CampoInput = style.TextInput`
  background-color: #fff;
  border-color: #333;
  border-radius: 5px;
  border-style: solid;
  border-width: 1px;
  margin: 10px 0;
  padding: 8px 5px;
  font-size: 1rem;
  width: 90%;
`;

export{
  CampoInput
}