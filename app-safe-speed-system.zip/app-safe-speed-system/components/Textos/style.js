import style from 'styled-components/native'

const Description = style.Text`
  font-size: 1rem;
  text-align: center;
  width: 280px;
`;
const Hero = style.Text`
  color: #f39c12;
  font-size: 1rem;
  text-align: center;
`;
export{
  Description,
  Hero
}